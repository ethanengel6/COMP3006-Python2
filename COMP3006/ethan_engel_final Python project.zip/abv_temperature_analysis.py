# Dan Saubert & Ethan Engel
# COMP 3006
# Final Project, main combined module
import logging
from statistics import mode

import matplotlib.pyplot as plt

import beers
import brewery_map

logger = logging.getLogger()


class USBreweries:
	def __init__(self):
		self.list_of_beers = beers.BeerList()
		self.states = [self.add_beer_list_to_state(state) for state in brewery_map.BreweriesByState().states]
		logger.debug("States loaded with beer lists")

	def search_for_brewery(self, brewery_id):
		matching_beers = []
		for beer in self.list_of_beers.beers:
			if beer.brewery_id == brewery_id:
				matching_beers.append(beer)
		return matching_beers

	def plot_abv_total_histogram(self):
		abv = []
		for beer in self.list_of_beers.beers:
			abv.append(beer.abv)
		plt.hist(abv)
		plt.title("ABV Frequency")
		plt.xlabel("Alcohol by Volume")
		plt.ylabel("Frequency")
		plt.show()

	def plot_beers_per_state_histogram(self):
		beer_count = [(state.state_name, len(state.beer_list)) for state in self.states]
		x, y = zip(*beer_count)
		plt.figure(figsize=(13, 6))
		plt.bar(x, y)
		plt.title("Number of Beers per State")
		plt.xlabel("State")
		plt.ylabel("Number of Beers")
		plt.show()

	def plot_beer_style_vs_temperature(self):
		x, y, label= zip(*[(self.get_most_popular_beer_type(state), state.temperature, state.state_name) for state in
		                   self.states])
		annotations = [(x[i], y[i], label[i]) for i in range(len(x))]
		plt.figure(figsize=(6,13))
		plt.scatter(x, y)
		plt.title("Temperature Averages by most popular Beer Style in a state")
		plt.xlabel("Beer Style")
		plt.ylabel("Annual Average Temperature")
		for annotation in annotations:
			plt.annotate(annotation[2], xy=(annotation[0], annotation[1]), xytext=(annotation[0], annotation[1] +		                                                                       .2))
		plt.show()

	def plot_temperature_spread_for_each_beer_style(self):
		states_for_each_type_of_beer = []
		for type_of_beer in beers.beer_types:
			states_for_each_type_of_beer.extend((self.find_states_carrying_type(type_of_beer)))
		x, y, label = zip(*states_for_each_type_of_beer)
		annotations = [(x[i], y[i], label[i]) for i in range(len(x))]
		plt.figure(figsize=(13, 13))
		plt.scatter(x, y)
		plt.title("Temperature Averages by Beer Style")
		plt.xlabel("Beer Style")
		plt.ylabel("Annual Average Temperature")
		plt.xticks(rotation=90)
		for annotation in annotations:
			plt.annotate(annotation[2], xy=(annotation[0], annotation[1]), xytext=(annotation[0], annotation[1] + .2))
		plt.show()

	def add_beer_list_to_state(self, state: brewery_map.StateBreweries):
		beer_list = []
		for brewery_id in state.breweries:
			beer_list.extend(self.search_for_brewery(brewery_id))
		state.beer_list = beer_list
		return state

	def get_most_popular_beer_type(self, state):
		beer_types = [beer.style for beer in state.beer_list]
		return mode(beer_types)

	def find_states_carrying_type(self, type_of_beer):
		carrying_states = []
		for state in self.states:
			for beer in state.beer_list:
				if beer.style == type_of_beer:
					carrying_states.append((type_of_beer, state.temperature, state.state_name))
					break
		return carrying_states


def main():
	us_breweries = USBreweries()
	us_breweries.plot_abv_total_histogram()
	us_breweries.plot_beers_per_state_histogram()
	us_breweries.plot_beer_style_vs_temperature()
	us_breweries.plot_temperature_spread_for_each_beer_style()
	print("The only notable correlation between temperature and beer style is for the Cider category, which appears "
	      "to have a tight bunching around states with average temperatures of about 45 to 52 degrees. However, "
	      "our initial question was to predict the most popular beer style based on the temperature, which appears "
	      "to show no correlation"
	      "other than the fact that most states prefer a 'General Ale' style of beer. The states that prefer IPAs "
	      "have a very loose correlation around the 45 to 55 degree annual average temperature.")
	exit(0)


if __name__ == '__main__':
	main()
