# Dan Saubert
# COMP 3006
# Final Project - Individual Module
import argparse
import csv
import logging
import os
from collections import defaultdict

import matplotlib.pyplot as plt
import numpy as np

brewery_data_csv_filename = "breweries.csv"
logger = logging.getLogger()
temperature_data_csv_filename = "state_temps.csv"
us_state_abbrev = {
	'Alabama': 'AL',
	'Alaska': 'AK',
	'American Samoa': 'AS',
	'Arizona': 'AZ',
	'Arkansas': 'AR',
	'California': 'CA',
	'Colorado': 'CO',
	'Connecticut': 'CT',
	'Delaware': 'DE',
	'District of Columbia': 'DC',
	'Florida': 'FL',
	'Georgia': 'GA',
	'Guam': 'GU',
	'Hawaii': 'HI',
	'Idaho': 'ID',
	'Illinois': 'IL',
	'Indiana': 'IN',
	'Iowa': 'IA',
	'Kansas': 'KS',
	'Kentucky': 'KY',
	'Louisiana': 'LA',
	'Maine': 'ME',
	'Maryland': 'MD',
	'Massachusetts': 'MA',
	'Michigan': 'MI',
	'Minnesota': 'MN',
	'Mississippi': 'MS',
	'Missouri': 'MO',
	'Montana': 'MT',
	'Nebraska': 'NE',
	'Nevada': 'NV',
	'New Hampshire': 'NH',
	'New Jersey': 'NJ',
	'New Mexico': 'NM',
	'New York': 'NY',
	'North Carolina': 'NC',
	'North Dakota': 'ND',
	'Northern Mariana Islands': 'MP',
	'Ohio': 'OH',
	'Oklahoma': 'OK',
	'Oregon': 'OR',
	'Pennsylvania': 'PA',
	'Puerto Rico': 'PR',
	'Rhode Island': 'RI',
	'South Carolina': 'SC',
	'South Dakota': 'SD',
	'Tennessee': 'TN',
	'Texas': 'TX',
	'Utah': 'UT',
	'Vermont': 'VT',
	'Virgin Islands': 'VI',
	'Virginia': 'VA',
	'Washington': 'WA',
	'West Virginia': 'WV',
	'Wisconsin': 'WI',
	'Wyoming': 'WY'
}


def convert_to_abbreviation(name):
	return us_state_abbrev.get(name)


class State:
	def __init__(self, name: str, average_temp: str):
		logger.debug("Creating state")
		self.name = convert_to_abbreviation(name)
		logger.debug("State name successfully converted to abbreviation")
		self.average_temp = float(average_temp)

	def __repr__(self):
		return self.name, self.average_temp

	def __str__(self):
		return str(self.__repr__())


class StateData:
	def __init__(self):
		self.states = None
		self._load_data()

	def __repr__(self):
		return self.states

	def __str__(self):
		return str(self.__repr__())

	def _load_data(self):
		logger.debug("Loading State csv.")
		if not os.path.exists(temperature_data_csv_filename):
			logger.critical("State average temperature csv does not exist or cannot be found.")
			exit(1)
		with open(temperature_data_csv_filename, 'r') as temperature_csv:
			reader = csv.reader(temperature_csv, delimiter=',', skipinitialspace=True)
			next(reader)
			self.states = np.array([State(*row) for row in reader])
		logger.info("States loaded successfully.")

	def plot_average_temps(self):
		logger.debug("Plotting average temps by state")
		# self._sort_states()
		x, y = zip(*[state.__repr__() for state in self.states])
		plt.figure(figsize=(13, 6))
		plt.title("Average Annual Temperature by State")
		plt.xlabel("State")
		plt.xticks(rotation=90)
		plt.ylabel("Annual Temperature")
		plt.bar(x, y, align="center")
		plt.show()

	def _sort_states(self):
		logger.debug("Sorting by states")
		state_temps = defaultdict(list)
		for state in self.states:
			state_temps[state.name].append(state.average_temp)
		self.states = dict(sorted({state: state_temps[state][0] for state in state_temps}))


class Brewery:
	def __init__(self, brewery_id: str, name: str, city: str, state: str):
		logger.debug("Creating new brewery")
		self.brewery_id = int(brewery_id)
		self.name = name
		self.city = city
		self.state = state

	def __repr__(self):
		return self.brewery_id, self.name, self.city, self.state

	def __str__(self):
		return str(self.__repr__())


class BreweryData:

	def __init__(self):
		self.breweries = None
		self._load_data()

	def _load_data(self):
		logger.debug("Loading brewery csv.")
		if not os.path.exists(brewery_data_csv_filename):
			logger.critical("Brewery csv does not exist or cannot be found.")
			exit(1)
		with open(brewery_data_csv_filename, 'r') as brewery_csv:
			reader = csv.reader(brewery_csv, delimiter=',', skipinitialspace=True)
			next(reader)
			self.breweries = np.array([Brewery(*row) for row in reader])
		logger.info("Breweries loaded successfully.")

	def _generate_state_brewery_density(self):
		logger.debug("Generating brewery density.")
		state_density = defaultdict(list)
		number_of_breweries = len(self.breweries)
		for brewery in self.breweries:
			state_density[brewery.state].append(brewery.brewery_id)
		self.brewery_densities = dict(sorted({state: (len(state_density.get(state)) / number_of_breweries) for
		                                      state in
		                                      state_density.keys()}.items()))

	def plot_brewery_density(self):
		logger.debug("Plotting brewery density")
		self._generate_state_brewery_density()
		x, y = zip(*self.brewery_densities.items())
		plt.figure(figsize=(13, 6))
		plt.title("Density of Breweries by State")
		plt.xlabel("State")
		plt.ylabel("Density of breweries")
		plt.xticks(rotation=90)
		plt.bar(x, y, align="center")
		plt.show()


class StateBreweries:
	def __init__(self, brewery_data: BreweryData, state: State):
		logger.debug("Creating complete state data entry")
		self.state_name = state.name
		self.temperature = state.average_temp
		self.breweries = []
		for brewery in brewery_data.breweries:
			if brewery.state == self.state_name:
				self.breweries.append(brewery.brewery_id)

	def __repr__(self):
		return self.state_name, self.temperature, self.breweries

	def __str__(self):
		return str(self.__repr__())


class BreweriesByState:
	def __init__(self):
		self.states = generate_list_of_states(BreweryData(), StateData())

	def __repr__(self):
		return self.states

	def __str__(self):
		return str(self.__repr__())


def brewery_by_temp(states):
	logger.debug("Plotting brewery vs temperature by state")
	x = []
	y = []
	label = []
	for state in states:
		x.append(state.temperature)
		y.append(len(state.breweries))
		label.append(state.state_name)
	plt.scatter(x, y)
	annotations = [(x[i], y[i], label[i]) for i in range(len(x))]
	for annotation in annotations:
		plt.annotate(annotation[2], xy=(annotation[0], annotation[1]), xytext=(annotation[0] - .5, annotation[1] +
		                                                                       .65))
	plt.xlabel("Average Annual Temperature in Fahrenheit")
	plt.ylabel("Total number of breweries")
	plt.title("Average Temperature vs # of Breweries by State in the US")
	plt.show()


def main():
	logger.setLevel(logging.DEBUG)
	arg_parser = argparse.ArgumentParser(description="analyze Craft Brewery data set")

	arg_parser.add_argument('command',
	                        metavar='<command>',
	                        type=str,
	                        help="which command to execute")

	arg_parser.add_argument('-p', '--plot',
	                        metavar="<plotname>",
	                        type=str,
	                        help="name of the plot that should be displayed. Options include: brewery_density, "
	                             "annual_temperature, and brewery_by_temp")

	arg_parser.add_argument('-o', '--ofile',
	                        metavar="<outfile>",
	                        type=str,
	                        default="sys.stdout",
	                        help="name of the outfile the data output should be sent to")

	args = arg_parser.parse_args()
	logger.debug("Proper arguments passed")
	brewery_data = BreweryData()
	state_data = StateData()
	states = generate_list_of_states(brewery_data, state_data)
	logger.debug("Data successfully loaded")
	if args.command == "print":
		for state in states:
			print(state)

	if args.ofile:
		with open(args.ofile, 'w', newline="") as csv_output:
			csv_writer = csv.writer(csv_output)
			csv_writer.writerow(["state", "average_temperature", "breweries"])
			for state in states:
				csv_writer.writerow(state.__repr__())

	if args.plot == "brewery_density":
		brewery_data.plot_brewery_density()
	elif args.plot == "annual_temperature":
		state_data.plot_average_temps()
	elif args.plot == "brewery_by_temp":
		brewery_by_temp(states)

	exit(0)


def generate_list_of_states(brewery_data, state_data):
	states = []
	for state in state_data.states:
		states.append(StateBreweries(brewery_data, state))
	return states


if __name__ == '__main__':
	main()
