import sys

dailyAvgList=[]

for q in sys.stdin:
    if float(q.strip('\n'))>-200:
        dailyAvgList.append(float(q.strip('\n')))

average = sum(dailyAvgList)/len(dailyAvgList)

if len(dailyAvgList)%2==1:
    median=dailyAvgList[int(len(dailyAvgList)/2)]
else:
    median=(dailyAvgList[int(len(dailyAvgList)/2)]+dailyAvgList[int(len(dailyAvgList)/2)-1])/2


print('min: ',min(dailyAvgList),', max: ', max(dailyAvgList),', average: ', average, ', median: ', median)
