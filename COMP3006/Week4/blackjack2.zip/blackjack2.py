
def main():

    import sys,csv
    from collections import namedtuple,defaultdict

    try:#Making sure all of the arguments passed in a reasonable
       handSims = int(sys.argv[1])

    except ValueError:
        print("The sys argument is as follows:  [1]=number of simulated hands(int)")
        sys.exit(1)

    #hand_total_list=[]
    #hand_total_count = defaultdict(int)
    #busts=0
    #hands=0

    #global stand_on_soft
    #global stand_on_value

    for stand_on_value in range(13,20):
        for sh in range(2):
            if sh==0:
                stand_on_soft=False
            else:
                stand_on_soft=True

            hand_total_list=[]
            hand_total_count = defaultdict(int)

            for xx in range(handSims):#simulation loop
                total=play_hand(stand_on_value, stand_on_soft)

                if total > 21:
                    hand_total_list.append('BUST')
                else:
                    hand_total_list.append(total)

            for hands in hand_total_list:
                hand_total_count[hands] += 1

            with open('blackjackdata.csv', 'w',newline='') as f:
                headers = ['13','14','15','16','17','18','19','20','21','BUST']
                f_csv = csv.DictWriter(f, headers)
                f_csv.writeheader()
                f_csv.writerows(hand_total_count)


                    #print("Bust percentage=",round(busts/hands*100,2))  #output

def get_card():
    import random
    return random.randint (1,13)



def score(cards):
    from collections import namedtuple
    Score=namedtuple('Score', 'total soft_ace_count')
    total=0
    soft_ace_count=0
    for w in range(len(cards)):
         if cards[w]==1:
             cards.append(cards.pop(w))
    for q in range(len(cards)):
        if cards[q]>=2 and cards[q]<=10:
            total+=cards[q]
        elif cards[q]>10:
            total+=10
        else:
            if total<=10:
                total+=11
                soft_ace_count+=1
            else:
                total +=1
    hand_score=Score(total, soft_ace_count)
    return hand_score



def stand(cards):
    from collections import namedtuple
    Stand=namedtuple('Stand','stand total')

    #hand_score=score(cards)

    

    if stand_on_soft==True:
        if hand_score[0]>=stand_on_value:
            return Stand(True, hand_score[0])
        else:
            return Stand(False, hand_score[0])
    else:
        if hand_score[1]==0 and hand_score[0]>=stand_on_value:
            return Stand(True, hand_score[0])
        elif hand_score[1]==0 and hand_score[0]<stand_on_value:
            return Stand(False, hand_score[0])
        elif hand_score[1]!=0 and hand_score[0]>stand_on_value:
            return Stand(True, hand_score[0])
        else:
            return Stand(False, hand_score[0])

def play_hand(stand_on_value, stand_on_soft):

    #total=0
    cards=[get_card(),get_card()]#Drawing initial hand

    while True:
        hand_score=score(cards)

        if stand(cards)==(False, hand_score[0]):
            cards.append(get_card())#hit
        else:
            break
    return total


if __name__ == '__main__':
        main()
