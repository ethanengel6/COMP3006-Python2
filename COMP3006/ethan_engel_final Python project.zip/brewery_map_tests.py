# Dan Saubert
# COMP 3006
# Final Project - Individual Module Tests
import unittest

import brewery_map


class BreweryTests(unittest.TestCase):

	def setUp(self):
		self.brewery = brewery_map.Brewery("2", "Ore Dock", "Marquette", "MI")

	def test_constructor(self):
		self.Brewery = brewery_map.Brewery("1", "Blackrocks", "Marquette", "MI")
		self.assertTrue(self.Brewery)

	def test_repr(self):
		self.assertEqual(self.brewery.__repr__(), (2, "Ore Dock", "Marquette", "MI"))


class BreweryDataTests(unittest.TestCase):

	def setUp(self):
		self.brewery_data = brewery_map.BreweryData()

	def test_successful_setup(self):
		self.assertNotEqual(len(self.brewery_data.breweries), 0)

	def test_brewery_creation(self):
		brewery_entry = self.brewery_data.breweries[0]
		self.assertEqual(type(brewery_entry), brewery_map.Brewery)


class StateTests(unittest.TestCase):

	def test_successful_setup(self):
		self.assertEqual(brewery_map.State("Michigan", "33.3").average_temp, 33.3)

class StateDataTests(unittest.TestCase):

	def test_state_setup(self):
		self.state_data = brewery_map.StateData()
		self.assertEqual(type(self.state_data.states[0]), brewery_map.State)


if __name__ == '__main__':
	unittest.main()
