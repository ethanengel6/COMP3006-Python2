# Dan Saubert & Ethan Engel
# COMP 3006
# Final Project, main combined module test cases
from unittest import TestCase

import abv_temperature_analysis


class TestUSBreweries(TestCase):

	def setUp(self):
		self.us_breweries = abv_temperature_analysis.USBreweries()

	def test_brewery_setup(self):
		self.assertIsNotNone(self.us_breweries.states)
		self.assertIsNotNone(self.us_breweries.list_of_beers)

	def test_brewery_search(self):
		search_results = self.us_breweries.search_for_brewery(1)
		self.assertNotEqual(search_results, [])

	def test_state_brewery_to_beer_list(self):
		state = self.us_breweries.states[0]
		updated_to_beer_list_state = self.us_breweries.add_beer_list_to_state(state)
		self.assertIsNotNone(updated_to_beer_list_state.beer_list)

	def test_beer_list_conversion(self):
		for state in self.us_breweries.states:
			self.assertNotEqual(state.beer_list, [])

	def test_most_popular_beer_type(self):
		state = self.us_breweries.states[0]
		beer_type = self.us_breweries.get_most_popular_beer_type(state)
		self.assertIsNotNone(beer_type)

	def test_find_states_carrying_type(self):
		states_that_carry_beer_type = []
		states_that_carry_beer_type = self.us_breweries.find_states_carrying_type("IPA")
		self.assertNotEqual(states_that_carry_beer_type, [])
